"""
IELTS Expert & AI Writing Coach - Backend Service (Python / FastAPI)
------------------------------------------------------------------
This Python backend provides the API endpoints for essay grading, 
lexical analysis, study plan generation, and student submission tracking.

Requirements:
    pip install fastapi uvicorn pydantic google-genai python-dotenv

To run:
    uvicorn app:app --reload --port 8000
"""

import os
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="IELTS Expert AI Backend",
    description="API for IELTS Writing Evaluation, Vocabulary Coach, and Student Management",
    version="1.0.0"
)

# Enable CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data Models
class EssaySubmission(BaseModel):
    prompt: str
    essay_text: str
    task_type: str = Field(default="Writing Task 2", description="Writing Task 1 or Task 2")
    target_band: float = 7.5
    user_id: Optional[str] = "student_01"

class RevisionUpdate(BaseModel):
    essay_id: str
    original_text: str
    revised_text: str

class VocabularyQuery(BaseModel):
    text: str
    context: Optional[str] = None

# Mock Database Store (Replace with SQL / Firestore in production)
SUBMISSIONS_DB = []
STUDENTS_DB = [
    {
        "id": "std_1",
        "name": "Emily Watson",
        "email": "emily.w@edu.com",
        "status": "ACTIVE",
        "avg_band": 7.5,
        "latest_essay": "Global Warming Impacts"
    },
    {
        "id": "std_2",
        "name": "Liam Chen",
        "email": "liam.c@provider.net",
        "status": "PENDING REVIEW",
        "avg_band": 6.0,
        "latest_essay": "Education in Tech"
    },
    {
        "id": "std_3",
        "name": "Sophie Bernard",
        "email": "s.bernard@mail.com",
        "status": "INACTIVE",
        "avg_band": None,
        "latest_essay": "No recent submissions"
    }
]

@app.get("/")
def root():
    return {
        "status": "online",
        "service": "IELTS Expert Python Backend",
        "version": "1.0.0",
        "endpoints": [
            "/api/evaluate-essay",
            "/api/vocabulary/analyze",
            "/api/compare-essay",
            "/api/trainer/students",
            "/api/auth/send-code"
        ]
    }

@app.post("/api/auth/send-code")
def send_auth_code(email: str = Body(..., embed=True)):
    """Simulates sending a 6-digit OTP code to student email."""
    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="Invalid email address")
    return {
        "success": True,
        "message": f"Verification code sent to {email}",
        "demo_code": "123456"
    }

@app.post("/api/evaluate-essay")
def evaluate_essay(submission: EssaySubmission):
    """
    Evaluates an IELTS essay based on official 4 criteria:
    Task Response, Coherence & Cohesion, Lexical Resource, Grammatical Range & Accuracy.
    """
    word_count = len(submission.essay_text.split())
    if word_count < 50:
        raise HTTPException(status_code=400, detail="Essay is too short for meaningful analysis (min 50 words).")

    # Sample calculated response (integrate Google Gemini API here in production)
    result = {
        "id": f"sub_{len(SUBMISSIONS_DB) + 1}",
        "word_count": word_count,
        "overall_band": 7.5,
        "cefr_level": "C1 Advanced",
        "criteria": {
            "task_response": 8.0,
            "coherence_cohesion": 7.5,
            "lexical_resource": 6.5,
            "grammatical_accuracy": 8.0
        },
        "focus_areas": [
            {
                "title": "Enhance Lexical Variety",
                "target": "Band 7.5+",
                "description": "Your essay uses 'important' multiple times. Consider academic synonyms like 'paramount', 'pivotal', or 'crucial'.",
                "original_example": "Education is important for children...",
                "improved_example": "Education is paramount for children..."
            },
            {
                "title": "Subject-Verb Agreement",
                "target": "Band 8.0+",
                "description": "Ensure singular vs plural consistency in complex sentences.",
                "original_example": "The collection of data suggest that...",
                "improved_example": "The collection of data suggests that..."
            }
        ]
    }
    SUBMISSIONS_DB.append(result)
    return result

@app.post("/api/vocabulary/analyze")
def analyze_vocabulary(query: VocabularyQuery):
    """Categorizes vocabulary into Fix, Enhance, Clarify, and Keep."""
    return {
        "fix_count": 0,
        "enhance_count": 5,
        "clarify_count": 2,
        "keep_count": 87,
        "suggestions": [
            {
                "phrase": "good",
                "original_sentence": "It is a good way to learn.",
                "type": "enhance",
                "alternatives": ["effective", "efficient"]
            },
            {
                "phrase": "think that",
                "original_sentence": "Many people think that technology is bad.",
                "type": "enhance",
                "alternatives": ["contend that", "maintain that"]
            },
            {
                "phrase": "important things",
                "original_sentence": "Education provides many important things.",
                "type": "clarify",
                "prompt": "State the exact idea you mean (e.g. core competencies, foundational knowledge)."
            }
        ]
    }

@app.get("/api/trainer/students")
def get_students():
    """Endpoint for Trainer Console student directory."""
    return {
        "total": len(STUDENTS_DB),
        "students": STUDENTS_DB,
        "upgrade_requests": [
            {"name": "Amara Miller", "tier": "Requested Platinum Tier", "time": "2h ago"},
            {"name": "Rahul Kapoor", "tier": "Requested 1-on-1 Session", "time": "5h ago"},
            {"name": "Sarah Lin", "tier": "Gold Extension", "time": "1d ago"}
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
