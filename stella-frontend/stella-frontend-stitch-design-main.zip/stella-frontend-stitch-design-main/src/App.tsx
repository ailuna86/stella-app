import React, { useState } from 'react';
import { ScreenId } from './types';
import { SignInScreen } from './components/screens/SignInScreen';
import { OnboardingScreen } from './components/screens/OnboardingScreen';
import { AIConsentScreen } from './components/screens/AIConsentScreen';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { GoldDashboardScreen } from './components/screens/GoldDashboardScreen';
import { PracticeSessionScreen } from './components/screens/PracticeSessionScreen';
import { WritingCoachScreen } from './components/screens/WritingCoachScreen';
import { RevisionWorkspaceScreen } from './components/screens/RevisionWorkspaceScreen';
import { EssayComparisonScreen } from './components/screens/EssayComparisonScreen';
import { VocabularyCoachScreen } from './components/screens/VocabularyCoachScreen';
import { FeedbackReportScreen } from './components/screens/FeedbackReportScreen';
import { StudyPlanScreen } from './components/screens/StudyPlanScreen';
import { PricingScreen } from './components/screens/PricingScreen';
import { TrainerConsoleScreen } from './components/screens/TrainerConsoleScreen';
import { ComingSoonScreen } from './components/screens/ComingSoonScreen';
import { PythonModal } from './components/PythonModal';
import { NavigationSwitcher } from './components/NavigationSwitcher';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('dashboard');
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'signin':
        return <SignInScreen onNavigate={setCurrentScreen} />;
      case 'onboarding':
        return <OnboardingScreen onNavigate={setCurrentScreen} />;
      case 'ai_consent':
        return <AIConsentScreen onNavigate={setCurrentScreen} />;
      case 'dashboard':
        return <DashboardScreen onNavigate={setCurrentScreen} />;
      case 'gold_dashboard':
        return <GoldDashboardScreen onNavigate={setCurrentScreen} />;
      case 'practice':
        return <PracticeSessionScreen onNavigate={setCurrentScreen} />;
      case 'writing_coach':
        return <WritingCoachScreen onNavigate={setCurrentScreen} />;
      case 'revision':
        return <RevisionWorkspaceScreen onNavigate={setCurrentScreen} />;
      case 'essay_comparison':
        return <EssayComparisonScreen onNavigate={setCurrentScreen} />;
      case 'vocab_coach':
        return <VocabularyCoachScreen onNavigate={setCurrentScreen} />;
      case 'feedback_report':
        return <FeedbackReportScreen onNavigate={setCurrentScreen} />;
      case 'study_plan':
        return <StudyPlanScreen onNavigate={setCurrentScreen} />;
      case 'pricing':
        return <PricingScreen onNavigate={setCurrentScreen} />;
      case 'trainer_console':
        return <TrainerConsoleScreen onNavigate={setCurrentScreen} />;
      case 'coming_soon':
        return <ComingSoonScreen onNavigate={setCurrentScreen} />;
      default:
        return <DashboardScreen onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#fcf9f3] text-[#1c1c19] selection:bg-[#3b309e] selection:text-white">
      {renderScreen()}

      {/* Floating Navigator & Python Downloader CTA */}
      <NavigationSwitcher
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        onOpenPythonModal={() => setIsPythonModalOpen(true)}
      />

      {/* Python Source Code Modal */}
      <PythonModal
        isOpen={isPythonModalOpen}
        onClose={() => setIsPythonModalOpen(false)}
      />
    </div>
  );
}
