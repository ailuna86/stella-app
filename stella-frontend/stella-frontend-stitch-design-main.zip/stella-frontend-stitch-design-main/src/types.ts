export type ScreenId =
  | 'signin'
  | 'onboarding'
  | 'dashboard'
  | 'gold_dashboard'
  | 'practice'
  | 'writing_coach'
  | 'revision'
  | 'essay_comparison'
  | 'vocab_coach'
  | 'feedback_report'
  | 'study_plan'
  | 'pricing'
  | 'trainer_console'
  | 'coming_soon'
  | 'ai_consent';

export interface Student {
  id: string;
  name: string;
  email: string;
  status: 'ACTIVE' | 'PENDING REVIEW' | 'INACTIVE';
  latestEssay: string;
  avgBand: number | null;
  avatar: string;
}

export interface UpgradeRequest {
  name: string;
  tier: string;
  time: string;
  initials: string;
  bg: string;
}
