import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const RevisionWorkspaceScreen: React.FC<Props> = ({ onNavigate }) => {
  const [filter, setFilter] = useState<'all' | 'red' | 'yellow' | 'mixed'>('all');
  const [revisedParagraph, setRevisedParagraph] = useState(
    "In today's globalized economy, occupational stability has transformed significantly. While retaining position within a single enterprise offers unquestionable job security, frequent career transitions empower ambitious professionals to cultivate versatile skill sets and accelerate career trajectory."
  );

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Top Bar */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('gold_dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Gold Revision Workspace</h1>
              <span className="px-2 py-0.5 rounded bg-[#D97706]/10 text-[#D97706] text-[10px] font-bold">LIVE AI</span>
            </div>
            <p className="text-xs text-[#888780]">Essay #104 • Line-by-Line Refinement</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('essay_comparison')}
            className="px-4 py-2 rounded-full border border-[#3b309e] text-[#3b309e] text-xs font-semibold hover:bg-[#e3dfff]/20 transition-all flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[16px]">compare</span>
            Compare Views
          </button>
          <button
            onClick={() => onNavigate('feedback_report')}
            className="px-4 py-2 rounded-full bg-[#3b309e] text-white text-xs font-semibold hover:bg-[#534ab7] transition-all"
          >
            View Feedback
          </button>
        </div>
      </header>

      {/* Main Grid */}
      <main className="max-w-[1280px] mx-auto p-6 md:p-10 space-y-8">
        {/* Filters */}
        <section className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#888780] mr-2">Highlight Filter:</span>
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                filter === 'all' ? 'bg-[#3b309e] text-white' : 'bg-[#f6f3ee] text-[#474553] hover:bg-[#ebe8e2]'
              }`}
            >
              Show all
            </button>
            <button
              onClick={() => setFilter('red')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                filter === 'red' ? 'bg-[#993556] text-white' : 'bg-[#FBEAF0] text-[#993556] hover:bg-[#f3d4df]'
              }`}
            >
              Only Red (Grammar/Errors)
            </button>
            <button
              onClick={() => setFilter('yellow')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                filter === 'yellow' ? 'bg-[#D97706] text-white' : 'bg-[#fff7e6] text-[#D97706] hover:bg-[#fedc97]'
              }`}
            >
              Only Yellow (Vocabulary)
            </button>
          </div>

          <div className="text-xs text-[#888780] font-medium">
            3 suggestions remaining for Paragraph 1
          </div>
        </section>

        {/* Content Split View */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Annotated Text Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-[#f1ede8] pb-3">
                <span className="font-bold text-xs uppercase tracking-wider text-[#3b309e]">Annotated Paragraph 1</span>
                <span className="text-xs text-[#0F6E56] font-semibold">CEFR B2 → Target C1</span>
              </div>

              <div className="text-sm leading-relaxed text-[#1c1c19] space-y-3 font-normal">
                <p>
                  In today's rapidly changing economy,{' '}
                  <span className="bg-[#fff7e6] text-[#D97706] font-semibold px-1 rounded border-b-2 border-[#D97706]">
                    job mobility
                  </span>{' '}
                  has become a subject of considerable debate. Some argue that remaining in a{' '}
                  <span className="bg-[#FBEAF0] text-[#993556] font-semibold px-1 rounded border-b-2 border-[#993556]">
                    single company
                  </span>{' '}
                  for one's whole life ensures stability, while others contend that changing employers frequently fosters professional growth.
                </p>
              </div>

              {/* Inline Cards */}
              <div className="space-y-3 pt-2">
                <div className="p-4 rounded-xl bg-[#fff7e6] border border-[#D97706]/30 space-y-1">
                  <div className="flex items-center justify-between text-xs font-bold text-[#D97706]">
                    <span>LEXICAL UPGRADE</span>
                    <span>Yellow Highlight</span>
                  </div>
                  <p className="text-xs text-[#1c1c19]">
                    'job mobility' → Replace with <strong>'occupational fluidity'</strong> or <strong>'career transition'</strong> for academic weight.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#FBEAF0] border border-[#993556]/30 space-y-1">
                  <div className="flex items-center justify-between text-xs font-bold text-[#993556]">
                    <span>REPETITION FIX</span>
                    <span>Red Highlight</span>
                  </div>
                  <p className="text-xs text-[#1c1c19]">
                    'single company' → Replace with <strong>'sole enterprise'</strong> to avoid repeating 'company' from the prompt.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Live Editor Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-white rounded-2xl p-6 border border-[#3b309e]/30 shadow-md space-y-4 flex flex-col h-full">
              <div className="flex items-center justify-between border-b border-[#f1ede8] pb-3">
                <span className="font-bold text-xs uppercase tracking-wider text-[#3b309e]">Your Live Revision</span>
                <span className="text-xs font-bold text-[#3b309e]">AI Assistant Active</span>
              </div>

              <textarea
                value={revisedParagraph}
                onChange={(e) => setRevisedParagraph(e.target.value)}
                rows={8}
                className="w-full p-4 rounded-xl bg-[#f6f3ee]/50 text-sm text-[#1c1c19] border border-[#c8c4d5]/30 focus:outline-none focus:bg-white focus:border-[#3b309e] focus:ring-2 focus:ring-[#3b309e]/10 transition-all resize-none custom-scrollbar"
              />

              <div className="flex items-center justify-between pt-4 border-t border-[#f1ede8]">
                <button
                  onClick={() => onNavigate('essay_comparison')}
                  className="px-4 py-2 rounded-full border border-[#3b309e] text-[#3b309e] text-xs font-semibold hover:bg-[#3b309e]/5"
                >
                  Compare with Model
                </button>

                <button
                  onClick={() => alert("Re-evaluating revised paragraph...")}
                  className="px-6 py-2.5 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow hover:bg-[#534ab7]"
                >
                  Resubmit Revision
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
