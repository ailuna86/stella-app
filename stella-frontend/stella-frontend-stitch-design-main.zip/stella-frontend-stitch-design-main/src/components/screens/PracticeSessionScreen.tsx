import React, { useState, useEffect } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const PracticeSessionScreen: React.FC<Props> = ({ onNavigate }) => {
  const [essayText, setEssayText] = useState(
    "In today's rapidly changing economy, job mobility has become a subject of considerable debate. Some argue that remaining in a single company for one's entire career ensures stability, while others contend that changing employers frequently fosters professional growth and broader skill acquisition. In my opinion, while long-term loyalty offers clear benefits, strategic job changes ultimately yield greater advantages for modern professionals."
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [timer, setTimer] = useState(2400); // 40 mins in seconds
  const [wordCount, setWordCount] = useState(0);

  useEffect(() => {
    const words = essayText.trim() ? essayText.trim().split(/\s+/).length : 0;
    setWordCount(words);
  }, [essayText]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onNavigate('feedback_report');
    }, 2000);
  };

  return (
    <div className={`bg-[#fcf9f3] min-h-screen text-[#1c1c19] flex flex-col ${isFullscreen ? 'fixed inset-0 z-50 overflow-auto bg-white' : ''}`}>
      {/* Loading Overlay */}
      {isSubmitting && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center text-white animate-in fade-in">
          <div className="w-20 h-20 rounded-full bg-[#3b309e] flex items-center justify-center mb-6 animate-bounce shadow-2xl">
            <span className="material-symbols-outlined text-[40px] text-white">auto_awesome</span>
          </div>
          <h2 className="text-2xl font-bold mb-2">Reading your essay carefully...</h2>
          <p className="text-sm text-[#e3dfff] max-w-md">
            Our AI examiner is evaluating your Task Response, Coherence, Lexical Resource, and Grammatical Accuracy against official IELTS standards.
          </p>
        </div>
      )}

      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 flex items-center justify-between sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Academic Writing Task 2</h1>
            <p className="text-xs text-[#888780]">Essay Practice • General Training or Academic</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#f6f3ee] border border-[#c8c4d5]/40 text-xs font-semibold text-[#3b309e]">
            <span className="material-symbols-outlined text-[16px]">timer</span>
            <span>{formatTimer(timer)}</span>
          </div>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-xl border border-[#c8c4d5]/40 hover:bg-[#f6f3ee] text-[#474553]"
            title="Toggle Fullscreen"
          >
            <span className="material-symbols-outlined">{isFullscreen ? 'fullscreen_exit' : 'fullscreen'}</span>
          </button>

          <button
            onClick={handleSubmit}
            className="px-6 py-2.5 rounded-full bg-[#3b309e] text-white font-semibold text-xs shadow-md hover:bg-[#534ab7] transition-all active:scale-95"
          >
            Submit for Evaluation
          </button>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 max-w-[1280px] w-full mx-auto p-6 md:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Prompt Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-[#c8c4d5]/30 space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-3 py-1 rounded-full bg-[#e3dfff] text-[#3b309e] text-xs font-bold">
                TASK 2 • DISCUSS BOTH VIEWS
              </span>
              <span className="text-xs text-[#888780] font-medium">Recommended: 250+ words</span>
            </div>

            <h2 className="font-bold text-lg text-[#2C2C2A] leading-snug">
              Some people think that it is best to work in the same organization for one's whole life. Others think that it is better to change jobs frequently.
            </h2>

            <p className="text-xs text-[#474553] leading-relaxed">
              Discuss both views and give your own opinion. Include relevant examples from your knowledge or experience.
            </p>
          </div>

          {/* Guidelines Accordion */}
          <div className="bg-[#f6f3ee] rounded-2xl p-5 border border-[#c8c4d5]/30 space-y-3">
            <h3 className="font-bold text-xs uppercase tracking-wider text-[#3b309e] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px]">checklist</span>
              Checklist before submitting
            </h3>
            <ul className="text-xs text-[#474553] space-y-2">
              <li className="flex items-start gap-2">
                <span className="material-symbols-outlined text-[#0F6E56] text-[16px] mt-0.5">check_circle</span>
                <span>Clear thesis statement in the introduction</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="material-symbols-outlined text-[#0F6E56] text-[16px] mt-0.5">check_circle</span>
                <span>At least two distinct body paragraphs discussing both views</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="material-symbols-outlined text-[#0F6E56] text-[16px] mt-0.5">check_circle</span>
                <span>Varied complex sentences and academic cohesive devices</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Text Area Column */}
        <div className="lg:col-span-7 flex flex-col space-y-4">
          <div className="bg-white rounded-2xl p-6 shadow-md border border-[#c8c4d5]/30 flex-1 flex flex-col">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#f1ede8] text-xs text-[#888780]">
              <span className="font-semibold text-[#1c1c19]">Essay Response</span>
              <div className="flex items-center gap-4">
                <span className={wordCount >= 250 ? 'text-[#0F6E56] font-bold' : 'text-[#D97706] font-bold'}>
                  {wordCount} / 250 words
                </span>
              </div>
            </div>

            <textarea
              value={essayText}
              onChange={(e) => setEssayText(e.target.value)}
              placeholder="Type your essay response here..."
              className="w-full flex-1 min-h-[380px] p-4 rounded-xl bg-[#f6f3ee]/50 text-[#1c1c19] text-sm leading-relaxed border border-[#c8c4d5]/20 focus:outline-none focus:bg-white focus:border-[#3b309e] focus:ring-2 focus:ring-[#3b309e]/10 transition-all resize-none custom-scrollbar"
            />

            <div className="flex items-center justify-between pt-4 mt-2 border-t border-[#f1ede8]">
              <button
                onClick={() => alert("Draft saved locally!")}
                className="px-4 py-2 rounded-full border border-[#c8c4d5] text-[#474553] text-xs font-semibold hover:bg-[#f6f3ee] transition-colors flex items-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[16px]">save</span>
                Save Draft
              </button>

              <button
                onClick={handleSubmit}
                className="px-6 py-2.5 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow-md hover:bg-[#534ab7] transition-all"
              >
                Evaluate Essay Now
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
