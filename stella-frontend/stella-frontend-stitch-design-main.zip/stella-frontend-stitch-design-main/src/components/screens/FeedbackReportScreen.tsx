import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const FeedbackReportScreen: React.FC<Props> = ({ onNavigate }) => {
  const [expandedFocus, setExpandedFocus] = useState<number | null>(0);

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">IELTS Feedback Report</h1>
            <p className="text-xs text-[#888780]">Official 4-Criteria Band Evaluation</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('revision')}
            className="px-5 py-2.5 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow hover:bg-[#534ab7] transition-all"
          >
            Start Revision
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-[1100px] mx-auto p-6 md:p-10 space-y-8">
        {/* Top Overall Score Gauge Card */}
        <section className="bg-white rounded-3xl p-8 border border-[#c8c4d5]/30 shadow-md flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-6">
            <div className="relative flex items-center justify-center shrink-0">
              <svg className="w-32 h-32 transform -rotate-90">
                <circle className="text-[#f6f3ee]" cx="64" cy="64" fill="transparent" r="56" stroke="currentColor" strokeWidth="10" />
                <circle className="text-[#3b309e]" cx="64" cy="64" fill="transparent" r="56" stroke="currentColor" strokeDasharray="351" strokeDashoffset="87" strokeWidth="10" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-extrabold text-[#3b309e]">7.5</span>
                <span className="text-[10px] text-[#888780] font-bold">OVERALL</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="px-3 py-1 rounded-full bg-[#E1F5EE] text-[#0F6E56] text-xs font-bold inline-block">
                CEFR C1 Advanced
              </span>
              <h2 className="font-extrabold text-2xl text-[#1c1c19]">Strong Academic Performance</h2>
              <p className="text-xs text-[#888780] max-w-md">
                Your writing demonstrates well-developed paragraphs, consistent grammatical range, and logical progression throughout.
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigate('practice')}
            className="px-6 py-3 rounded-full border-2 border-[#3b309e] text-[#3b309e] font-semibold text-xs hover:bg-[#3b309e]/5"
          >
            Practice Next Prompt
          </button>
        </section>

        {/* 4 Criteria Breakdown Grid */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Criterion 1 */}
          <div className="bg-white p-6 rounded-2xl border border-[#c8c4d5]/30 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-[#1c1c19]">Task Response</span>
              <span className="font-extrabold text-lg text-[#3b309e]">8.0</span>
            </div>
            <div className="w-full bg-[#f6f3ee] h-2 rounded-full overflow-hidden">
              <div className="bg-[#3b309e] h-full w-[88%]" />
            </div>
            <p className="text-xs text-[#888780]">Fully addresses all parts of the prompt with well-supported ideas.</p>
          </div>

          {/* Criterion 2 */}
          <div className="bg-white p-6 rounded-2xl border border-[#c8c4d5]/30 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-[#1c1c19]">Coherence & Cohesion</span>
              <span className="font-extrabold text-lg text-[#3b309e]">7.5</span>
            </div>
            <div className="w-full bg-[#f6f3ee] h-2 rounded-full overflow-hidden">
              <div className="bg-[#3b309e] h-full w-[78%]" />
            </div>
            <p className="text-xs text-[#888780]">Sequences information logically with clear paragraphing.</p>
          </div>

          {/* Criterion 3 */}
          <div className="bg-white p-6 rounded-2xl border border-[#c8c4d5]/30 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-[#1c1c19]">Lexical Resource</span>
              <span className="font-extrabold text-lg text-[#D97706]">6.5</span>
            </div>
            <div className="w-full bg-[#f6f3ee] h-2 rounded-full overflow-hidden">
              <div className="bg-[#D97706] h-full w-[65%]" />
            </div>
            <p className="text-xs text-[#888780]">Sufficient range; needs less common vocabulary for Band 7.5+.</p>
          </div>

          {/* Criterion 4 */}
          <div className="bg-white p-6 rounded-2xl border border-[#c8c4d5]/30 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-[#1c1c19]">Grammatical Range</span>
              <span className="font-extrabold text-lg text-[#3b309e]">8.0</span>
            </div>
            <div className="w-full bg-[#f6f3ee] h-2 rounded-full overflow-hidden">
              <div className="bg-[#3b309e] h-full w-[85%]" />
            </div>
            <p className="text-xs text-[#888780]">Uses a wide variety of complex structures with rare minor errors.</p>
          </div>
        </section>

        {/* Priority Focus Areas */}
        <section className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm space-y-4">
          <h3 className="font-bold text-base text-[#1c1c19]">Priority Focus Areas for Revision</h3>

          <div className="space-y-3">
            {/* Focus 1 */}
            <div className="border border-[#c8c4d5]/30 rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedFocus(expandedFocus === 0 ? null : 0)}
                className="w-full p-4 bg-[#f6f3ee]/50 text-left flex items-center justify-between font-semibold text-xs text-[#1c1c19]"
              >
                <span>1. Upgrade Lexical Precision (Band 6.5 → 7.5)</span>
                <span className="material-symbols-outlined text-sm">{expandedFocus === 0 ? 'expand_less' : 'expand_more'}</span>
              </button>
              {expandedFocus === 0 && (
                <div className="p-4 space-y-3 bg-white text-xs text-[#474553]">
                  <p>In Paragraph 2, you wrote: <em>"Education provides many important things."</em></p>
                  <div className="p-3 bg-[#fff7e6] text-[#D97706] rounded-lg font-medium">
                    Suggested: <em>"Education confers essential cognitive and social competencies."</em>
                  </div>
                </div>
              )}
            </div>

            {/* Focus 2 */}
            <div className="border border-[#c8c4d5]/30 rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedFocus(expandedFocus === 1 ? null : 1)}
                className="w-full p-4 bg-[#f6f3ee]/50 text-left flex items-center justify-between font-semibold text-xs text-[#1c1c19]"
              >
                <span>2. Avoid Informal Overuse of 'Get' and 'Things'</span>
                <span className="material-symbols-outlined text-sm">{expandedFocus === 1 ? 'expand_less' : 'expand_more'}</span>
              </button>
              {expandedFocus === 1 && (
                <div className="p-4 space-y-3 bg-white text-xs text-[#474553]">
                  <p>In Paragraph 3, replace informal verbs like <em>'get jobs'</em> with <em>'secure employment'</em>.</p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
