import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const EssayComparisonScreen: React.FC<Props> = ({ onNavigate }) => {
  const [showFullModel, setShowFullModel] = useState(false);

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('gold_dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">3-Column Essay Comparison</h1>
            <p className="text-xs text-[#888780]">Original Draft vs Your Revision vs Band 9 Model</p>
          </div>
        </div>

        <button
          onClick={() => setShowFullModel(!showFullModel)}
          className="px-4 py-2 rounded-full bg-[#3b309e] text-white text-xs font-semibold hover:bg-[#534ab7] transition-all flex items-center gap-1.5"
        >
          <span className="material-symbols-outlined text-[16px]">visibility</span>
          {showFullModel ? 'Hide Full Model' : 'View Full Band 9 Model'}
        </button>
      </header>

      {/* Main Container */}
      <main className="max-w-[1400px] mx-auto p-6 md:p-10 space-y-8">
        {/* Full Model Drawer Banner if toggled */}
        {showFullModel && (
          <div className="bg-[#3b309e] text-white p-6 rounded-3xl shadow-xl animate-in fade-in space-y-4">
            <div className="flex items-center justify-between border-b border-white/20 pb-3">
              <span className="font-bold text-xs uppercase tracking-wider text-[#e3dfff]">Band 9.0 Official Model Answer</span>
              <button onClick={() => setShowFullModel(false)} className="text-white hover:text-[#e3dfff]">
                <span className="material-symbols-outlined text-sm">close</span>
              </button>
            </div>
            <p className="text-sm leading-relaxed text-[#f6f3ee] italic">
              "In contemporary discourse regarding career development, opinion remains divided on whether lifelong loyalty to a single employer is preferable to periodic job changes. While remaining in one organization offers structural security, I firmly maintain that changing positions enables individuals to acquire broader expertise and cultivate professional resilience."
            </p>
          </div>
        )}

        {/* 3 Column Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Col 1: Original */}
          <div className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-[#f1ede8] pb-3">
              <span className="font-bold text-xs uppercase tracking-wider text-[#888780]">1. Original Draft</span>
              <span className="px-2 py-0.5 rounded bg-[#FBEAF0] text-[#993556] text-[10px] font-bold">Band 6.5</span>
            </div>
            <p className="text-xs text-[#474553] leading-relaxed">
              In today's rapidly changing economy, job mobility has become a subject of considerable debate. Some argue that remaining in a single company for one's whole life ensures stability, while others contend that changing employers frequently fosters professional growth.
            </p>
          </div>

          {/* Col 2: Your Revision */}
          <div className="bg-white rounded-2xl p-6 border border-[#3b309e]/30 shadow-md space-y-4">
            <div className="flex items-center justify-between border-b border-[#f1ede8] pb-3">
              <span className="font-bold text-xs uppercase tracking-wider text-[#3b309e]">2. Your Revision</span>
              <span className="px-2 py-0.5 rounded bg-[#E1F5EE] text-[#0F6E56] text-[10px] font-bold">Band 7.5</span>
            </div>
            <p className="text-xs text-[#1c1c19] font-medium leading-relaxed">
              In today's globalized economy, occupational stability has transformed significantly. While retaining position within a single enterprise offers unquestionable job security, frequent career transitions empower ambitious professionals to cultivate versatile skill sets.
            </p>
          </div>

          {/* Col 3: AI Band 9 Rewrite */}
          <div className="bg-white rounded-2xl p-6 border border-[#D97706]/30 shadow-sm gold-shimmer space-y-4">
            <div className="flex items-center justify-between border-b border-[#D97706]/20 pb-3">
              <span className="font-bold text-xs uppercase tracking-wider text-[#D97706]">3. Band 9.0 AI Model</span>
              <span className="px-2 py-0.5 rounded bg-[#fff7e6] text-[#D97706] text-[10px] font-bold">Optimal C2</span>
            </div>
            <p className="text-xs text-[#2C2C2A] font-medium leading-relaxed italic">
              In contemporary professional landscapes, occupational fluidity has increasingly supplanted traditional lifelong tenure. Although organizational fidelity offers undeniable security, frequent inter-firm mobility cultivates indispensable adaptability.
            </p>
          </div>
        </section>

        {/* Why this is stronger */}
        <section className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-[#1c1c19] flex items-center gap-2">
            <span className="material-symbols-outlined text-[#3b309e]">auto_awesome</span>
            Key Upgrades from Band 6.5 to Band 9.0
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#f6f3ee] border border-[#c8c4d5]/20 space-y-1">
              <span className="text-xs font-bold text-[#3b309e]">Cohesive Devices</span>
              <p className="text-xs text-[#474553]">
                'In today's rapidly changing economy' → 'In contemporary professional landscapes' (Higher academic register).
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#f6f3ee] border border-[#c8c4d5]/20 space-y-1">
              <span className="text-xs font-bold text-[#3b309e]">Collocations</span>
              <p className="text-xs text-[#474553]">
                'changing employers frequently' → 'frequent inter-firm mobility' (Precise domain terminology).
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
