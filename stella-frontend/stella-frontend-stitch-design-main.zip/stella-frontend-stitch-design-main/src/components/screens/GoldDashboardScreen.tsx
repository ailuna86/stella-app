import React from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const GoldDashboardScreen: React.FC<Props> = ({ onNavigate }) => {
  return (
    <div className="bg-[#fcf9f3] text-[#1c1c19] min-h-screen flex">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-[#f6f3ee] border-r border-[#c8c4d5]/30 p-6 hidden md:flex flex-col justify-between shrink-0">
        <div className="space-y-8">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#3b309e] text-[28px] fill-1">school</span>
            <span className="font-extrabold text-xl text-[#3b309e]">ST.ELLA</span>
            <span className="px-2 py-0.5 rounded bg-[#D97706]/10 text-[#D97706] text-[10px] font-bold">GOLD</span>
          </div>

          <nav className="space-y-2">
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[#3b309e] text-white font-semibold text-xs shadow-md">
              <span className="material-symbols-outlined text-[18px]">grid_view</span>
              Dashboard
            </button>
            <button onClick={() => onNavigate('revision')} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#474553] hover:bg-[#ebe8e2] font-semibold text-xs transition-colors">
              <span className="material-symbols-outlined text-[18px]">edit_note</span>
              Revision Workspace
            </button>
            <button onClick={() => onNavigate('essay_comparison')} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#474553] hover:bg-[#ebe8e2] font-semibold text-xs transition-colors">
              <span className="material-symbols-outlined text-[18px]">compare</span>
              Essay Comparison
            </button>
            <button onClick={() => onNavigate('vocab_coach')} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#474553] hover:bg-[#ebe8e2] font-semibold text-xs transition-colors">
              <span className="material-symbols-outlined text-[18px]">spellcheck</span>
              Vocabulary Coach
            </button>
            <button onClick={() => onNavigate('study_plan')} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#474553] hover:bg-[#ebe8e2] font-semibold text-xs transition-colors">
              <span className="material-symbols-outlined text-[18px]">event_repeat</span>
              Study Plan
            </button>
            <button onClick={() => onNavigate('trainer_console')} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#474553] hover:bg-[#ebe8e2] font-semibold text-xs transition-colors">
              <span className="material-symbols-outlined text-[18px]">supervisor_account</span>
              Trainer Console
            </button>
          </nav>
        </div>

        <div className="bg-[#e3dfff]/40 p-4 rounded-xl border border-[#3b309e]/10">
          <div className="flex items-center gap-2 text-[#3b309e] font-bold text-xs mb-1">
            <span className="material-symbols-outlined text-[16px]">support_agent</span>
            1-on-1 Mentor
          </div>
          <p className="text-[11px] text-[#474553]">Your mentor review is scheduled for Thursday, 15:00 UTC.</p>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top bar */}
        <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => onNavigate('dashboard')} className="md:hidden text-[#3b309e]">
              <span className="material-symbols-outlined">menu</span>
            </button>
            <h1 className="font-bold text-xl text-[#1c1c19]">Gold Member Workspace</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-[#E1F5EE] text-[#0F6E56] text-xs font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#0F6E56] animate-ping" />
              Active Pass
            </span>
            <button onClick={() => onNavigate('dashboard')} className="text-xs font-semibold text-[#3b309e] hover:underline">
              Standard View
            </button>
          </div>
        </header>

        <main className="p-6 md:p-10 space-y-8 flex-1 overflow-auto">
          {/* Gold Banner */}
          <section className="gold-shimmer rounded-3xl p-8 gold-border shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-3">
              <span className="bg-[#D97706]/15 text-[#D97706] text-xs font-bold px-3 py-1 rounded-full border border-[#D97706]/30 inline-block">
                ⚡ EXCLUSIVE GOLD FEATURES UNLOCKED
              </span>
              <h2 className="font-extrabold text-2xl md:text-3xl text-[#2C2C2A]">
                Targeting Band 8.0 Mastery
              </h2>
              <p className="text-sm text-[#474553] max-w-xl">
                You have unlimited live AI re-evaluations, side-by-side paragraph rewrites, and direct tutor line access.
              </p>
            </div>
            <div className="flex items-center gap-4 bg-white/80 backdrop-blur-md p-4 rounded-2xl border border-[#D97706]/20">
              <div className="text-center px-4 border-r border-[#c8c4d5]/40">
                <span className="text-xs text-[#888780] font-bold block">STREAK</span>
                <span className="text-2xl font-extrabold text-[#D97706]">12 Days</span>
              </div>
              <div className="text-center px-4">
                <span className="text-xs text-[#888780] font-bold block">NEXT REVISION</span>
                <span className="text-2xl font-extrabold text-[#3b309e]">Today</span>
              </div>
            </div>
          </section>

          {/* Performance Grid */}
          <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
              <span className="text-xs text-[#888780] font-semibold">Task Response</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-extrabold text-[#3b309e]">7.5</span>
                <span className="text-xs text-[#0F6E56] font-bold">+0.5</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
              <span className="text-xs text-[#888780] font-semibold">Coherence & Cohesion</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-extrabold text-[#3b309e]">8.0</span>
                <span className="text-xs text-[#0F6E56] font-bold">+1.0</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
              <span className="text-xs text-[#888780] font-semibold">Lexical Resource</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-extrabold text-[#3b309e]">7.0</span>
                <span className="text-xs text-[#D97706] font-bold">Needs Focus</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
              <span className="text-xs text-[#888780] font-semibold">Grammatical Accuracy</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-extrabold text-[#3b309e]">7.5</span>
                <span className="text-xs text-[#0F6E56] font-bold">+0.5</span>
              </div>
            </div>
          </section>

          {/* Gold Action Cards */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div
              onClick={() => onNavigate('revision')}
              className="bg-white p-6 rounded-2xl border border-[#3b309e]/20 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-[#e3dfff] flex items-center justify-center text-[#3b309e] mb-4">
                  <span className="material-symbols-outlined text-[24px]">edit_note</span>
                </div>
                <h3 className="font-bold text-lg text-[#1c1c19] mb-2">Live Revision Workspace</h3>
                <p className="text-xs text-[#888780] leading-relaxed mb-6">
                  Refine paragraph by paragraph with color-coded suggestions and live AI feedback.
                </p>
              </div>
              <span className="text-xs font-bold text-[#3b309e] flex items-center gap-1">
                Open Workspace <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </span>
            </div>

            <div
              onClick={() => onNavigate('essay_comparison')}
              className="bg-white p-6 rounded-2xl border border-[#3b309e]/20 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-[#e3dfff] flex items-center justify-center text-[#3b309e] mb-4">
                  <span className="material-symbols-outlined text-[24px]">compare</span>
                </div>
                <h3 className="font-bold text-lg text-[#1c1c19] mb-2">3-Column Comparison</h3>
                <p className="text-xs text-[#888780] leading-relaxed mb-6">
                  Compare your original draft side-by-side with your revised version and Band 9 model rewrite.
                </p>
              </div>
              <span className="text-xs font-bold text-[#3b309e] flex items-center gap-1">
                Compare Essays <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </span>
            </div>

            <div
              onClick={() => onNavigate('study_plan')}
              className="bg-white p-6 rounded-2xl border border-[#3b309e]/20 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-[#e3dfff] flex items-center justify-center text-[#3b309e] mb-4">
                  <span className="material-symbols-outlined text-[24px]">event_repeat</span>
                </div>
                <h3 className="font-bold text-lg text-[#1c1c19] mb-2">Targeted Roadmap</h3>
                <p className="text-xs text-[#888780] leading-relaxed mb-6">
                  Structured 4-week practice schedule dynamically tailored to fix your specific error patterns.
                </p>
              </div>
              <span className="text-xs font-bold text-[#3b309e] flex items-center gap-1">
                View Study Plan <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </span>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};
