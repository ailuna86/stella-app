import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const PricingScreen: React.FC<Props> = ({ onNavigate }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Choose Your Plan</h1>
            <p className="text-xs text-[#888780]">Flexible options for every IELTS goal</p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-[#f6f3ee] p-1 rounded-full border border-[#c8c4d5]/40 text-xs font-semibold">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-3 py-1 rounded-full transition-all ${
              billingCycle === 'monthly' ? 'bg-[#3b309e] text-white shadow' : 'text-[#474553]'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle('yearly')}
            className={`px-3 py-1 rounded-full transition-all ${
              billingCycle === 'yearly' ? 'bg-[#3b309e] text-white shadow' : 'text-[#474553]'
            }`}
          >
            Yearly (Save 20%)
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-[1100px] mx-auto p-6 md:p-10 space-y-12">
        <div className="text-center space-y-3 max-w-xl mx-auto">
          <h2 className="font-extrabold text-3xl text-[#1c1c19]">Invest in Your Band Score</h2>
          <p className="text-sm text-[#474553]">
            Get access to expert AI essay evaluations, live revision workspaces, and 1-on-1 tutor feedback.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          {/* Premium Plan */}
          <div className="bg-white rounded-3xl p-8 border border-[#c8c4d5]/40 shadow-sm flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <span className="px-3 py-1 rounded-full bg-[#f6f3ee] text-[#3b309e] text-xs font-bold inline-block">
                PREMIUM
              </span>
              <h3 className="font-bold text-xl text-[#1c1c19]">Standard Practice</h3>
              <div className="flex items-baseline gap-1">
                <span className="font-extrabold text-4xl text-[#1c1c19]">
                  {billingCycle === 'monthly' ? '$29' : '$23'}
                </span>
                <span className="text-xs text-[#888780] font-medium">/ month</span>
              </div>
              <p className="text-xs text-[#888780]">Ideal for self-directed students seeking detailed AI scoring.</p>

              <ul className="space-y-3 pt-4 border-t border-[#f1ede8] text-xs text-[#474553]">
                <li className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#0F6E56] text-sm">check_circle</span>
                  10 AI Essay Evaluations / month
                </li>
                <li className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#0F6E56] text-sm">check_circle</span>
                  Official 4-Criteria Band Scoring
                </li>
                <li className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#0F6E56] text-sm">check_circle</span>
                  Vocabulary Coach & Refinements
                </li>
              </ul>
            </div>

            <button
              onClick={() => onNavigate('dashboard')}
              className="w-full py-3.5 rounded-full border-2 border-[#3b309e] text-[#3b309e] font-semibold text-xs hover:bg-[#3b309e]/5 transition-all"
            >
              Select Premium Plan
            </button>
          </div>

          {/* Gold Plan */}
          <div className="bg-white rounded-3xl p-8 gold-border shadow-xl gold-shimmer relative flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full bg-[#D97706]/15 text-[#D97706] text-xs font-bold inline-block border border-[#D97706]/30">
                  RECOMMENDED • GOLD TIER
                </span>
                <span className="material-symbols-outlined text-[#D97706]">stars</span>
              </div>

              <h3 className="font-bold text-xl text-[#1c1c19]">Mastery & Coaching</h3>
              <div className="flex items-baseline gap-1">
                <span className="font-extrabold text-4xl text-[#D97706]">
                  {billingCycle === 'monthly' ? '$59' : '$47'}
                </span>
                <span className="text-xs text-[#888780] font-medium">/ month</span>
              </div>
              <p className="text-xs text-[#888780]">For serious candidates targeting Band 7.5+ with tutor oversight.</p>

              <ul className="space-y-3 pt-4 border-t border-[#f1ede8] text-xs text-[#1c1c19]">
                <li className="flex items-center gap-2 font-medium">
                  <span className="material-symbols-outlined text-[#D97706] text-sm">check_circle</span>
                  UNLIMITED AI Essay Evaluations
                </li>
                <li className="flex items-center gap-2 font-medium">
                  <span className="material-symbols-outlined text-[#D97706] text-sm">check_circle</span>
                  Live Line-by-Line Revision Workspace
                </li>
                <li className="flex items-center gap-2 font-medium">
                  <span className="material-symbols-outlined text-[#D97706] text-sm">check_circle</span>
                  3-Column Band 9 Model Comparison
                </li>
                <li className="flex items-center gap-2 font-medium">
                  <span className="material-symbols-outlined text-[#D97706] text-sm">check_circle</span>
                  1-on-1 Monthly Human Examiner Session
                </li>
              </ul>
            </div>

            <button
              onClick={() => onNavigate('gold_dashboard')}
              className="w-full py-3.5 rounded-full bg-[#3b309e] text-white font-semibold text-xs shadow-lg hover:bg-[#534ab7] transition-all"
            >
              Get Started with Gold
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
