import React from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const DashboardScreen: React.FC<Props> = ({ onNavigate }) => {
  return (
    <div className="bg-[#fcf9f3] text-[#1c1c19] min-h-screen pb-24 md:pb-12">
      {/* Top App Bar */}
      <header className="fixed top-0 w-full z-40 bg-[#f6f3ee] shadow-[0px_4px_20px_rgba(83,74,183,0.08)] flex items-center justify-between px-6 py-4 md:px-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full overflow-hidden bg-[#e3dfff] ring-2 ring-[#3b309e]/20">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDILyY3dbx54hOMH31L4CMoZVoc_QCJKvjO1UH177VNhOcbZRrluWWyqVzOyxh_RSS2_5mjNBkZEcPS8n5rdfbNZC9wc7wlVAk0cuY84qGpVGgQZn5PY-GDtWxyJ-T0svkk-cx_7Mjj1hCFtrgMnazALSGcA0i5H9U2e4HNS59E7f6_hBkKh2E3hmqNwwvaOKtcJlTeETkbJ-nXMLP61eKwzE29sawOyydjzloms-kGWS8uJQSvOq29"
              alt="Student"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h1 className="font-bold text-lg text-[#3b309e]">Hi, Student</h1>
            <button onClick={() => onNavigate('gold_dashboard')} className="text-xs text-[#D97706] font-semibold hover:underline flex items-center gap-1">
              <span className="material-symbols-outlined text-[14px] fill-1">stars</span> Switch to Gold View
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={() => onNavigate('pricing')} className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#3b309e] text-white text-xs font-semibold hover:bg-[#534ab7] transition-all">
            <span className="material-symbols-outlined text-[16px]">workspace_premium</span>
            Upgrade
          </button>
          <button className="p-2 rounded-full hover:bg-[#ebe8e2] transition-colors text-[#3b309e]">
            <span className="material-symbols-outlined">notifications</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[1200px] mx-auto px-6 md:px-10 py-6 space-y-8 pt-24">
        {/* Stats Row */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl shadow-[0px_4px_20px_rgba(83,74,183,0.08)] flex flex-col justify-between border border-[#c8c4d5]/30 hover:border-[#3b309e]/30 transition-all">
            <span className="text-xs text-[#888780] font-semibold uppercase tracking-wider">Current Band</span>
            <div className="flex items-baseline gap-1 mt-2">
              <span className="font-extrabold text-3xl text-[#3b309e]">6.5</span>
              <span className="material-symbols-outlined text-[#0F6E56] text-sm fill-1">trending_up</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-[0px_4px_20px_rgba(83,74,183,0.08)] flex flex-col justify-between border border-[#c8c4d5]/30 hover:border-[#3b309e]/30 transition-all">
            <span className="text-xs text-[#888780] font-semibold uppercase tracking-wider">Goal Band</span>
            <div className="mt-2">
              <span className="font-extrabold text-3xl text-[#5951b4]">7.5</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-[0px_4px_20px_rgba(83,74,183,0.08)] flex flex-col justify-between border border-[#c8c4d5]/30 hover:border-[#3b309e]/30 transition-all">
            <span className="text-xs text-[#888780] font-semibold uppercase tracking-wider">Sessions</span>
            <div className="mt-2">
              <span className="font-extrabold text-3xl text-[#1c1c19]">12</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-[0px_4px_20px_rgba(83,74,183,0.08)] flex flex-col justify-between border border-[#c8c4d5]/30 hover:border-[#3b309e]/30 transition-all">
            <span className="text-xs text-[#888780] font-semibold uppercase tracking-wider">Evaluations Left</span>
            <div className="mt-2">
              <span className="font-extrabold text-3xl text-[#993556]">03</span>
            </div>
          </div>
        </section>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Column */}
          <div className="md:col-span-8 space-y-6">
            {/* Homework Card */}
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-[#3b309e]/20 overflow-hidden relative">
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-[#534ab7] text-white p-2 rounded-xl material-symbols-outlined text-[20px]">assignment</span>
                <h2 className="font-bold text-xl text-[#1c1c19]">Homework</h2>
              </div>
              <div className="bg-[#f6f3ee] p-5 rounded-2xl border border-[#c8c4d5]/20 mb-6">
                <p className="text-xs text-[#3b309e] font-bold mb-2 uppercase tracking-wide">WRITING TASK 2</p>
                <p className="text-base font-medium text-[#2C2C2A] italic leading-relaxed">
                  "Some people think that it is best to work in the same organization for one's whole life. Others think that it is better to change jobs frequently. Discuss both views and give your opinion."
                </p>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4 text-xs text-[#888780] font-medium">
                  <span className="flex items-center gap-1"><span className="material-symbols-outlined text-sm">schedule</span> 40 mins</span>
                  <span className="flex items-center gap-1"><span className="material-symbols-outlined text-sm">description</span> 250 words</span>
                </div>
                <button
                  onClick={() => onNavigate('practice')}
                  className="bg-[#3b309e] text-white px-8 py-3 rounded-full font-semibold text-sm hover:shadow-xl hover:-translate-y-0.5 transition-all active:scale-95"
                >
                  Write my essay
                </button>
              </div>
            </div>

            {/* Daily Practice */}
            <div className="bg-white rounded-2xl p-6 shadow-[0px_4px_20px_rgba(83,74,183,0.08)] border border-[#c8c4d5]/30">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <span className="bg-[#9f97ff] text-[#33288d] p-2 rounded-xl material-symbols-outlined text-[20px]">rocket_launch</span>
                  <h2 className="font-bold text-xl text-[#1c1c19]">Daily practice</h2>
                </div>
                <span className="text-xs font-semibold text-[#0F6E56] flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#0F6E56] animate-pulse" />
                  New modules available
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  onClick={() => onNavigate('vocab_coach')}
                  className="flex items-center gap-4 p-4 rounded-2xl bg-[#f6f3ee] hover:bg-[#ebe8e2] transition-colors cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-full bg-[#e2e1f2] flex items-center justify-center text-[#3b309e] group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined">translate</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-[#1c1c19]">Vocabulary Boost</h3>
                    <p className="text-xs text-[#888780]">Academic Word List #4</p>
                  </div>
                </div>

                <div
                  onClick={() => onNavigate('writing_coach')}
                  className="flex items-center gap-4 p-4 rounded-2xl bg-[#f6f3ee] hover:bg-[#ebe8e2] transition-colors cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-full bg-[#e2e1f2] flex items-center justify-center text-[#3b309e] group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined">edit_note</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-[#1c1c19]">Sentence Mastery</h3>
                    <p className="text-xs text-[#888780]">Subordinating Conjunctions</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('practice')}
                className="w-full mt-6 py-3 rounded-full border-2 border-[#3b309e] text-[#3b309e] font-semibold text-sm hover:bg-[#3b309e]/5 transition-all active:scale-95"
              >
                Start session
              </button>
            </div>
          </div>

          {/* Right Column */}
          <div className="md:col-span-4 space-y-6">
            {/* Latest Evaluation Card */}
            <div className="bg-white rounded-2xl p-6 shadow-[0px_4px_20px_rgba(83,74,183,0.08)] border border-[#c8c4d5]/30 flex flex-col justify-between">
              <div>
                <h2 className="font-bold text-lg text-[#1c1c19] mb-4">Latest evaluation</h2>
                <div className="flex flex-col items-center justify-center text-center py-4">
                  <div className="relative mb-4">
                    <svg className="w-28 h-28 transform -rotate-90">
                      <circle className="text-[#ebe8e2]" cx="56" cy="56" fill="transparent" r="50" stroke="currentColor" strokeWidth="8" />
                      <circle className="text-[#3b309e]" cx="56" cy="56" fill="transparent" r="50" stroke="currentColor" strokeDasharray="314" strokeDashoffset="94" strokeWidth="8" />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-2xl font-extrabold text-[#3b309e]">7.0</span>
                      <span className="text-[10px] text-[#888780]">Band Score</span>
                    </div>
                  </div>
                  <p className="text-sm font-semibold text-[#2C2C2A] mb-1">Writing Task 1 Report</p>
                  <p className="text-xs text-[#888780] mb-6">Evaluated 2 hours ago</p>

                  <div className="w-full space-y-2 mb-6">
                    <div className="flex justify-between text-xs">
                      <span className="text-[#474553]">Coherence</span>
                      <span className="text-[#3b309e] font-bold">7.5</span>
                    </div>
                    <div className="w-full bg-[#ebe8e2] h-1.5 rounded-full overflow-hidden">
                      <div className="bg-[#3b309e] h-full w-[75%]" />
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-[#474553]">Grammar</span>
                      <span className="text-[#3b309e] font-bold">6.5</span>
                    </div>
                    <div className="w-full bg-[#ebe8e2] h-1.5 rounded-full overflow-hidden">
                      <div className="bg-[#3b309e] h-full w-[65%]" />
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('feedback_report')}
                className="w-full text-center flex items-center justify-center gap-1.5 text-[#3b309e] font-semibold text-xs hover:underline"
              >
                View full report
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
            </div>

            {/* Upcoming Session */}
            <div className="bg-[#534ab7] text-white rounded-2xl p-6 shadow-lg">
              <p className="text-[10px] uppercase font-bold opacity-80 mb-1">UPCOMING SESSION</p>
              <h3 className="font-bold text-lg mb-4">Speaking Mock Exam</h3>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-9 h-9 rounded-full overflow-hidden border border-white/30">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuAPRBdJj25GhxKdLxkaF3hGeKEmHMZETCha-rg4Oy249rnYD-PyXXsiODVbWUnAcdEBQmsNH1X7pLR4VeLBtv2Y7E5GUivy8-LYKmE-nv3i2ofpNvd6urAcgGnM-TVsWJi0Bu40k40ba6RSUas_7BO9upXfpOf6U6PpeI79a7kxIhFIBdqP60dLr-15zGb4d5C2dbWqL2KXyzeyetDw6dACPpROrxX-YvD2tlyVfRv01jWjtyMvxJIZ"
                    alt="Tutor"
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-xs font-medium">With Mr. David Harris</span>
              </div>
              <div className="flex items-center justify-between text-xs bg-white/10 p-3 rounded-xl">
                <span className="flex items-center gap-1.5"><span className="material-symbols-outlined text-sm">calendar_today</span> Oct 12</span>
                <span className="flex items-center gap-1.5"><span className="material-symbols-outlined text-sm">alarm</span> 14:30 PM</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
