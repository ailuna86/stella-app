import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const VocabularyCoachScreen: React.FC<Props> = ({ onNavigate }) => {
  const [filter, setFilter] = useState<'all' | 'enhance' | 'clarify' | 'keep'>('all');

  const vocabItems = [
    {
      phrase: 'good way',
      original: 'Online learning is a good way to gain new knowledge.',
      type: 'enhance',
      suggestion: 'an effective strategy / a viable conduit',
      band: 'Band 8.0+'
    },
    {
      phrase: 'think that',
      original: 'Many citizens think that governments should act.',
      type: 'enhance',
      suggestion: 'contend that / maintain that',
      band: 'Band 7.5+'
    },
    {
      phrase: 'important things',
      original: 'Education brings many important things to youth.',
      type: 'clarify',
      suggestion: 'foundational competencies / essential qualifications',
      band: 'Band 7.0+'
    },
    {
      phrase: 'occupational stability',
      original: 'Occupational stability has transformed significantly.',
      type: 'keep',
      suggestion: 'Mastered C1 Vocabulary',
      band: 'Band 8.0'
    }
  ];

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Vocabulary Coach</h1>
            <p className="text-xs text-[#888780]">Refine Your Lexis for Band 8.0+</p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('revision')}
          className="px-4 py-2 rounded-full bg-[#3b309e] text-white text-xs font-semibold hover:bg-[#534ab7] transition-all"
        >
          Open Workspace
        </button>
      </header>

      {/* Main Container */}
      <main className="max-w-[1100px] mx-auto p-6 md:p-10 space-y-8">
        {/* Metric Chips Header */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm text-center">
            <span className="text-xs text-[#888780] font-bold block">0 FIX</span>
            <span className="text-xl font-extrabold text-[#0F6E56]">Errors Resolved</span>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm text-center">
            <span className="text-xs text-[#888780] font-bold block">5 ENHANCE</span>
            <span className="text-xl font-extrabold text-[#D97706]">Upgrade Phrases</span>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm text-center">
            <span className="text-xs text-[#888780] font-bold block">2 CLARIFY</span>
            <span className="text-xl font-extrabold text-[#3b309e]">Vague Terms</span>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm text-center">
            <span className="text-xs text-[#888780] font-bold block">87 KEEP</span>
            <span className="text-xl font-extrabold text-[#1c1c19]">Advanced Words</span>
          </div>
        </section>

        {/* Filter Toolbar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'all' ? 'bg-[#3b309e] text-white' : 'bg-white border border-[#c8c4d5]/40 text-[#474553]'
            }`}
          >
            All Items (94)
          </button>
          <button
            onClick={() => setFilter('enhance')}
            className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'enhance' ? 'bg-[#D97706] text-white' : 'bg-white border border-[#c8c4d5]/40 text-[#D97706]'
            }`}
          >
            Enhance (5)
          </button>
          <button
            onClick={() => setFilter('clarify')}
            className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'clarify' ? 'bg-[#3b309e] text-white' : 'bg-white border border-[#c8c4d5]/40 text-[#3b309e]'
            }`}
          >
            Clarify (2)
          </button>
          <button
            onClick={() => setFilter('keep')}
            className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'keep' ? 'bg-[#0F6E56] text-white' : 'bg-white border border-[#c8c4d5]/40 text-[#0F6E56]'
            }`}
          >
            Keep (87)
          </button>
        </div>

        {/* Vocab Cards List */}
        <section className="space-y-4">
          {vocabItems
            .filter((item) => filter === 'all' || item.type === filter)
            .map((item, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-[#c8c4d5]/30 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-[#3b309e]/30 transition-all">
                <div className="space-y-2 max-w-xl">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-base text-[#1c1c19]">"{item.phrase}"</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#f6f3ee] text-[#3b309e]">
                      {item.band}
                    </span>
                  </div>
                  <p className="text-xs text-[#888780] italic">Original: "{item.original}"</p>
                </div>

                <div className="bg-[#f6f3ee] p-3 rounded-xl border border-[#c8c4d5]/20 text-xs font-semibold text-[#3b309e] flex items-center gap-2">
                  <span className="material-symbols-outlined text-sm">auto_awesome</span>
                  Suggested: {item.suggestion}
                </div>
              </div>
            ))}
        </section>
      </main>
    </div>
  );
};
