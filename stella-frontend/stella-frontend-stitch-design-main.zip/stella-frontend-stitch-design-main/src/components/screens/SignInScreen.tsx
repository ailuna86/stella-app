import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const SignInScreen: React.FC<Props> = ({ onNavigate }) => {
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [email, setEmail] = useState('student@university.edu');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);

  const handleOtpChange = (index: number, val: string) => {
    if (val.length > 1) val = val[val.length - 1];
    const newOtp = [...otp];
    newOtp[index] = val;
    setOtp(newOtp);

    // Auto advance
    if (val && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative p-6 bg-[#fcf9f3]">
      {/* Background blobs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[5%] w-[40vw] h-[40vw] rounded-full bg-[#3b309e]/5 blur-[60px]" />
        <div className="absolute top-[40%] -right-[10%] w-[50vw] h-[50vw] rounded-full bg-[#9f97ff]/10 blur-[60px]" />
        <div className="absolute -bottom-[10%] left-[20%] w-[35vw] h-[35vw] rounded-full bg-[#e2e1f2]/20 blur-[60px]" />
      </div>

      <main className="w-full max-w-[480px] z-10 my-8">
        <div className="text-center mb-10">
          <h1 className="font-bold text-3xl text-[#3b309e] tracking-tight mb-2">ST.ELLA</h1>
          <p className="text-[#888780] text-sm">Your supportive path to IELTS excellence.</p>
        </div>

        <div className="bg-white rounded-2xl shadow-[0px_4px_20px_rgba(83,74,183,0.08)] p-8 md:p-10 border border-[#c8c4d5]/30">
          {step === 'email' ? (
            <section className="space-y-6">
              <div className="text-center space-y-2">
                <h2 className="font-bold text-xl text-[#2C2C2A]">Welcome back</h2>
                <p className="text-xs text-[#888780]">Enter your student email to receive a secure sign-in code.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-[#474553] mb-1 ml-1" htmlFor="email">Email Address</label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-[#c8c4d5] bg-[#f6f3ee] text-[#1c1c19] text-sm focus:outline-none focus:border-[#3b309e] focus:ring-2 focus:ring-[#3b309e]/10 transition-all"
                    placeholder="student@university.edu"
                  />
                </div>

                <button
                  onClick={() => setStep('code')}
                  className="w-full py-3.5 bg-[#3b309e] text-white font-semibold text-sm rounded-full shadow-lg hover:bg-[#5951b4] transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  Send code
                  <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
                </button>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-xl bg-[#ebe8e2]/50 border border-[#c8c4d5]/30">
                <span className="material-symbols-outlined text-[#3b309e] text-[20px] mt-0.5">verified_user</span>
                <p className="text-xs text-[#474553] leading-relaxed">
                  We use one-time codes instead of passwords. It's more secure, easier to remember, and keeps your progress safe without the stress of forgotten credentials.
                </p>
              </div>
            </section>
          ) : (
            <section className="space-y-8">
              <div className="text-center space-y-2">
                <button
                  onClick={() => setStep('email')}
                  className="text-[#3b309e] hover:text-[#5951b4] flex items-center justify-center gap-1 mx-auto text-xs font-semibold mb-4 transition-colors"
                >
                  <span className="material-symbols-outlined text-[16px]">arrow_back</span>
                  Back to email
                </button>
                <h2 className="font-bold text-xl text-[#2C2C2A]">Verify your identity</h2>
                <p className="text-xs text-[#888780]">We sent a 6-digit code to <span className="font-medium text-[#1c1c19]">{email}</span></p>
              </div>

              <div className="space-y-6">
                <div className="flex justify-between gap-2">
                  {otp.map((digit, idx) => (
                    <input
                      key={idx}
                      id={`otp-${idx}`}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(idx, e)}
                      className="w-12 h-12 text-center text-lg font-bold rounded-xl border border-[#c8c4d5] bg-[#f6f3ee] focus:border-[#3b309e] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#3b309e]/10 transition-all"
                    />
                  ))}
                </div>

                <div className="space-y-4">
                  <button
                    onClick={() => onNavigate('dashboard')}
                    className="w-full py-3.5 bg-[#3b309e] text-white font-semibold text-sm rounded-full shadow-lg hover:bg-[#5951b4] transition-all active:scale-[0.98]"
                  >
                    Sign in to ST.ELLA
                  </button>
                  <div className="text-center">
                    <p className="text-xs text-[#474553]">
                      Didn't receive it?{' '}
                      <button onClick={() => setStep('code')} className="text-[#3b309e] font-semibold hover:underline ml-1">Resend code</button>
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 text-[#888780]">
                <span className="material-symbols-outlined text-[18px]">lock</span>
                <span className="text-xs font-medium">End-to-end encrypted session</span>
              </div>
            </section>
          )}
        </div>

        <footer className="mt-8 text-center space-x-6 text-xs text-[#888780]">
          <button onClick={() => onNavigate('coming_soon')} className="hover:text-[#3b309e] transition-colors">Help Center</button>
          <button onClick={() => onNavigate('ai_consent')} className="hover:text-[#3b309e] transition-colors">Privacy Policy</button>
          <button onClick={() => onNavigate('pricing')} className="hover:text-[#3b309e] transition-colors">Terms of Use</button>
        </footer>
      </main>
    </div>
  );
};
