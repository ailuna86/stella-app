import React from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const ComingSoonScreen: React.FC<Props> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-[#fcf9f3] text-[#1c1c19] flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-md w-full space-y-6">
        <div className="w-20 h-20 rounded-full bg-[#e3dfff] text-[#3b309e] flex items-center justify-center mx-auto animate-float shadow-lg">
          <span className="material-symbols-outlined text-[40px]">construction</span>
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 rounded-full bg-[#9f97ff]/20 text-[#33288d] text-xs font-bold">
            GENERAL TRAINING MODULE
          </span>
          <h1 className="font-extrabold text-2xl md:text-3xl text-[#1c1c19]">We're still crafting this!</h1>
          <p className="text-xs text-[#888780] leading-relaxed">
            General Training IELTS letter writing and workplace reading modules are currently undergoing final examiner validation.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-[#c8c4d5]/30 shadow-sm space-y-3">
          <p className="text-xs font-medium text-[#474553]">Get notified when General Training launches:</p>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="Enter your email"
              defaultValue="student@university.edu"
              className="flex-1 px-3 py-2 rounded-xl bg-[#f6f3ee] text-xs text-[#1c1c19] border border-[#c8c4d5]/30 focus:outline-none"
            />
            <button
              onClick={() => alert("Notification preference saved!")}
              className="px-4 py-2 rounded-xl bg-[#3b309e] text-white text-xs font-semibold hover:bg-[#534ab7]"
            >
              Notify Me
            </button>
          </div>
        </div>

        <button
          onClick={() => onNavigate('onboarding')}
          className="text-xs font-bold text-[#3b309e] hover:underline flex items-center justify-center gap-1 mx-auto"
        >
          <span className="material-symbols-outlined text-sm">arrow_back</span>
          Go back to Academic setup
        </button>
      </div>
    </div>
  );
};
