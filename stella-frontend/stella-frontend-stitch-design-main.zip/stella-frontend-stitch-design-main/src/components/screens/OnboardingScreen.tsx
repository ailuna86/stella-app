import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const OnboardingScreen: React.FC<Props> = ({ onNavigate }) => {
  const [selectedOption, setSelectedOption] = useState<'academic' | 'general' | null>('academic');

  const handleContinue = () => {
    if (selectedOption === 'general') {
      onNavigate('coming_soon');
    } else {
      onNavigate('ai_consent');
    }
  };

  return (
    <div className="min-h-screen bg-[#fcf9f3] text-[#1c1c19] flex flex-col">
      {/* Top Progress bar */}
      <div className="fixed top-0 left-0 w-full h-1.5 bg-[#ebe8e2] z-50">
        <div className="h-full bg-[#3b309e] w-[10%] transition-all duration-500 ease-out shadow-[0_0_8px_rgba(83,74,183,0.3)]" />
      </div>

      {/* Header */}
      <header className="w-full flex items-center justify-between px-6 md:px-10 py-6 pt-8">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#3b309e] flex items-center justify-center text-white">
            <span className="material-symbols-outlined !text-[20px] fill-1">school</span>
          </div>
          <span className="font-bold text-xl text-[#3b309e]">Tutorly</span>
        </div>
        <button
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-2 text-[#474553] hover:text-[#3b309e] transition-colors font-semibold text-sm"
        >
          <span>Exit Survey</span>
          <span className="material-symbols-outlined">close</span>
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-6 py-8">
        <div className="w-full max-w-[640px] flex flex-col">
          <div className="mb-4">
            <span className="bg-[#9f97ff]/20 text-[#33288d] px-3 py-1 rounded-full font-semibold text-xs">Step 1 of 10</span>
          </div>

          <h1 className="font-bold text-2xl md:text-3xl text-[#2C2C2A] mb-2">
            Which IELTS test are you taking?
          </h1>
          <p className="text-base text-[#474553] mb-8">
            This helps us tailor your study plan and practice materials to your specific goals.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {/* Academic Card */}
            <button
              onClick={() => setSelectedOption('academic')}
              className={`relative flex flex-col items-start p-6 rounded-2xl text-left transition-all duration-300 border ${
                selectedOption === 'academic'
                  ? 'border-[#3b309e] bg-[#e3dfff]/20 shadow-md ring-2 ring-[#3b309e]/10'
                  : 'border-[#c8c4d5] bg-white hover:-translate-y-0.5'
              }`}
            >
              <div className={`w-12 h-12 rounded-full mb-6 flex items-center justify-center transition-colors ${
                selectedOption === 'academic' ? 'bg-[#3b309e] text-white' : 'bg-[#e3dfff] text-[#3f35a3]'
              }`}>
                <span className="material-symbols-outlined !text-[28px] fill-1">menu_book</span>
              </div>
              <h3 className="font-bold text-lg text-[#2C2C2A] mb-2">Academic</h3>
              <p className="text-xs text-[#888780] leading-relaxed">
                Ideal for students applying for higher education or professional registration in an English-speaking environment.
              </p>
              {selectedOption === 'academic' && (
                <div className="absolute top-5 right-5 text-[#3b309e]">
                  <span className="material-symbols-outlined fill-1">check_circle</span>
                </div>
              )}
            </button>

            {/* General Training Card */}
            <button
              onClick={() => setSelectedOption('general')}
              className={`relative flex flex-col items-start p-6 rounded-2xl text-left transition-all duration-300 border ${
                selectedOption === 'general'
                  ? 'border-[#3b309e] bg-[#e3dfff]/20 shadow-md ring-2 ring-[#3b309e]/10'
                  : 'border-[#c8c4d5] bg-white hover:-translate-y-0.5'
              }`}
            >
              <div className={`w-12 h-12 rounded-full mb-6 flex items-center justify-center transition-colors ${
                selectedOption === 'general' ? 'bg-[#3b309e] text-white' : 'bg-[#e4dfff] text-[#41379b]'
              }`}>
                <span className="material-symbols-outlined !text-[28px] fill-1">work</span>
              </div>
              <h3 className="font-bold text-lg text-[#2C2C2A] mb-2">General Training</h3>
              <p className="text-xs text-[#888780] leading-relaxed">
                Perfect for migration, secondary education, or those looking to gain work experience in English-speaking countries.
              </p>
              {selectedOption === 'general' && (
                <div className="absolute top-5 right-5 text-[#3b309e]">
                  <span className="material-symbols-outlined fill-1">check_circle</span>
                </div>
              )}
            </button>
          </div>

          {/* Info Card */}
          <div className="bg-[#f6f3ee] p-5 rounded-2xl flex gap-4 items-start mb-10 border border-[#ebe8e2]">
            <span className="material-symbols-outlined text-[#3b309e] shrink-0">info</span>
            <p className="text-xs text-[#474553] leading-relaxed">
              Not sure which one to pick? The <strong className="text-[#2C2C2A]">Academic</strong> version focuses on university-level skills, while <strong className="text-[#2C2C2A]">General Training</strong> focuses on everyday context. Check your organization's requirements first.
            </p>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-auto">
            <button
              onClick={() => onNavigate('signin')}
              className="px-8 py-3 rounded-full font-semibold text-sm text-[#888780] hover:text-[#1c1c19] transition-colors"
            >
              Back
            </button>
            <button
              onClick={handleContinue}
              disabled={!selectedOption}
              className={`px-10 py-3 rounded-full font-semibold text-sm transition-all active:scale-95 shadow-md ${
                selectedOption
                  ? 'bg-[#3b309e] text-white hover:bg-[#534ab7]'
                  : 'bg-[#c8c4d5] text-white cursor-not-allowed opacity-60'
              }`}
            >
              Continue
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
