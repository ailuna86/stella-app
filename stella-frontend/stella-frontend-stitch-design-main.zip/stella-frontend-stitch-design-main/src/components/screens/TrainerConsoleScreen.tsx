import React, { useState } from 'react';
import { ScreenId, Student } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const TrainerConsoleScreen: React.FC<Props> = ({ onNavigate }) => {
  const [students] = useState<Student[]>([
    {
      id: 'std_1',
      name: 'Emily Watson',
      email: 'emily.w@edu.com',
      status: 'ACTIVE',
      avgBand: 7.5,
      latestEssay: 'Global Warming Impacts',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150'
    },
    {
      id: 'std_2',
      name: 'Liam Chen',
      email: 'liam.c@provider.net',
      status: 'PENDING REVIEW',
      avgBand: 6.0,
      latestEssay: 'Education in Tech',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150'
    },
    {
      id: 'std_3',
      name: 'Sophie Bernard',
      email: 's.bernard@mail.com',
      status: 'INACTIVE',
      avgBand: null,
      latestEssay: 'No recent submissions',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=150'
    }
  ]);

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Trainer Console</h1>
              <span className="px-2 py-0.5 rounded bg-[#3b309e] text-white text-[10px] font-bold">EXAMINER</span>
            </div>
            <p className="text-xs text-[#888780]">Student Essay Supervision & Grading Roster</p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('dashboard')}
          className="px-4 py-2 rounded-full border border-[#c8c4d5] text-[#474553] text-xs font-semibold hover:bg-[#f6f3ee]"
        >
          Student Mode
        </button>
      </header>

      {/* Main Container */}
      <main className="max-w-[1280px] mx-auto p-6 md:p-10 space-y-8">
        {/* Roster Overview Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
            <span className="text-xs text-[#888780] font-bold block">ASSIGNED STUDENTS</span>
            <span className="text-2xl font-extrabold text-[#3b309e] mt-1 block">24</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
            <span className="text-xs text-[#888780] font-bold block">PENDING REVIEWS</span>
            <span className="text-2xl font-extrabold text-[#D97706] mt-1 block">05</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
            <span className="text-xs text-[#888780] font-bold block">AVG STUDENT BAND</span>
            <span className="text-2xl font-extrabold text-[#0F6E56] mt-1 block">7.0</span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#c8c4d5]/30 shadow-sm">
            <span className="text-xs text-[#888780] font-bold block">GOLD UPGRADES</span>
            <span className="text-2xl font-extrabold text-[#1c1c19] mt-1 block">12</span>
          </div>
        </div>

        {/* Student Directory Table */}
        <section className="bg-white rounded-2xl border border-[#c8c4d5]/30 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-[#f1ede8] flex items-center justify-between">
            <h2 className="font-bold text-lg text-[#1c1c19]">Student Directory</h2>
            <div className="relative">
              <input
                type="text"
                placeholder="Search students..."
                className="pl-9 pr-4 py-2 rounded-xl bg-[#f6f3ee] text-xs text-[#1c1c19] border border-[#c8c4d5]/30 focus:outline-none focus:border-[#3b309e]"
              />
              <span className="material-symbols-outlined text-[16px] text-[#888780] absolute left-3 top-2.5">search</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#f6f3ee]/60 border-b border-[#f1ede8] text-[11px] font-bold text-[#888780] uppercase">
                  <th className="p-4 pl-6">Student</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Latest Essay</th>
                  <th className="p-4">Avg Band</th>
                  <th className="p-4 pr-6 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1ede8] text-xs text-[#1c1c19]">
                {students.map((student) => (
                  <tr key={student.id} className="hover:bg-[#f6f3ee]/30 transition-colors">
                    <td className="p-4 pl-6 flex items-center gap-3">
                      <img src={student.avatar} alt={student.name} className="w-9 h-9 rounded-full object-cover" />
                      <div>
                        <span className="font-bold text-[#1c1c19] block">{student.name}</span>
                        <span className="text-[11px] text-[#888780]">{student.email}</span>
                      </div>
                    </td>

                    <td className="p-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        student.status === 'ACTIVE'
                          ? 'bg-[#E1F5EE] text-[#0F6E56]'
                          : student.status === 'PENDING REVIEW'
                          ? 'bg-[#fff7e6] text-[#D97706]'
                          : 'bg-[#ebe8e2] text-[#888780]'
                      }`}>
                        {student.status}
                      </span>
                    </td>

                    <td className="p-4 text-[#474553]">{student.latestEssay}</td>

                    <td className="p-4 font-bold text-[#3b309e]">
                      {student.avgBand ? student.avgBand.toFixed(1) : 'N/A'}
                    </td>

                    <td className="p-4 pr-6 text-right">
                      <button
                        onClick={() => onNavigate('feedback_report')}
                        className="px-3 py-1.5 rounded-lg bg-[#3b309e] text-white text-[11px] font-semibold hover:bg-[#534ab7]"
                      >
                        Review Essay
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
};
