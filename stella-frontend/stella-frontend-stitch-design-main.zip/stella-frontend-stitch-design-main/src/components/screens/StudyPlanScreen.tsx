import React from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const StudyPlanScreen: React.FC<Props> = ({ onNavigate }) => {
  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-16">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 sticky top-0 z-30 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Custom IELTS Study Plan</h1>
            <p className="text-xs text-[#888780]">4-Week Structured Roadmap to Band 8.0</p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('practice')}
          className="px-5 py-2.5 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow hover:bg-[#534ab7] transition-all"
        >
          Resume Practice
        </button>
      </header>

      {/* Main Container */}
      <main className="max-w-[1100px] mx-auto p-6 md:p-10 space-y-8">
        {/* Banner */}
        <section className="bg-[#3b309e] text-white rounded-3xl p-8 shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold text-white">
              GOAL: BAND 8.0 ACADEMIC
            </span>
            <h2 className="font-extrabold text-2xl md:text-3xl">Week 3 in Progress</h2>
            <p className="text-xs text-[#e3dfff] max-w-lg">
              You have completed 65% of your customized study curriculum. Focus on Complex Structures and Cohesion this week.
            </p>
          </div>

          <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center min-w-[160px]">
            <span className="text-[10px] text-[#e3dfff] font-bold uppercase block">COMPLETION</span>
            <span className="text-3xl font-extrabold text-white">65%</span>
          </div>
        </section>

        {/* Timeline Weeks */}
        <section className="space-y-6">
          {/* Week 1 */}
          <div className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#E1F5EE] text-[#0F6E56] flex items-center justify-center font-bold shrink-0">
              <span className="material-symbols-outlined text-[20px]">check</span>
            </div>
            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base text-[#1c1c19]">Week 1: Task Response & Essay Layout</h3>
                <span className="text-xs font-bold text-[#0F6E56]">COMPLETED</span>
              </div>
              <p className="text-xs text-[#888780]">Introduction structures, thesis statements, and paragraph outlining.</p>
            </div>
          </div>

          {/* Week 2 */}
          <div className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#E1F5EE] text-[#0F6E56] flex items-center justify-center font-bold shrink-0">
              <span className="material-symbols-outlined text-[20px]">check</span>
            </div>
            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base text-[#1c1c19]">Week 2: Academic Vocabulary & Collocations</h3>
                <span className="text-xs font-bold text-[#0F6E56]">COMPLETED</span>
              </div>
              <p className="text-xs text-[#888780]">Topic-specific lexical sets (environment, education, tech).</p>
            </div>
          </div>

          {/* Week 3 */}
          <div className="bg-white rounded-2xl p-6 border-2 border-[#3b309e] shadow-md flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#3b309e] text-white flex items-center justify-center font-bold shrink-0">
              <span className="material-symbols-outlined text-[20px]">bolt</span>
            </div>
            <div className="space-y-2 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base text-[#3b309e]">Week 3: Complex Sentence Structures (Current)</h3>
                <span className="text-xs font-bold text-[#3b309e]">IN PROGRESS</span>
              </div>
              <p className="text-xs text-[#474553]">Subordinating clauses, inversions, and reduced relative clauses.</p>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => onNavigate('writing_coach')}
                  className="px-4 py-2 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow hover:bg-[#534ab7]"
                >
                  Start Sentence Coach
                </button>
              </div>
            </div>
          </div>

          {/* Week 4 */}
          <div className="bg-[#f6f3ee] rounded-2xl p-6 border border-[#c8c4d5]/30 opacity-70 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-[#ebe8e2] text-[#888780] flex items-center justify-center font-bold shrink-0">
              <span className="material-symbols-outlined text-[20px]">lock</span>
            </div>
            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base text-[#888780]">Week 4: Timed Mock Exams & Final Review</h3>
                <span className="text-xs font-bold text-[#888780]">LOCKED</span>
              </div>
              <p className="text-xs text-[#888780]">Simulated 60-minute IELTS Writing Task 1 & Task 2 test environment.</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
