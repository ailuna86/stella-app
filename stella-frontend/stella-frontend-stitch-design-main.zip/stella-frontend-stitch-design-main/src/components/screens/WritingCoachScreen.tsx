import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const WritingCoachScreen: React.FC<Props> = ({ onNavigate }) => {
  const [viewState, setViewState] = useState<'mission' | 'graded'>('mission');
  const [inputText, setInputText] = useState(
    "Although online learning offers unprecedented flexibility for adult professionals, it frequently lacks the social accountability and peer interaction that traditional classroom settings naturally provide."
  );

  return (
    <div className="bg-[#fcf9f3] min-h-screen text-[#1c1c19] pb-12">
      {/* Header */}
      <header className="px-6 py-4 bg-white border-b border-[#c8c4d5]/30 flex items-center justify-between sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate('dashboard')} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#3b309e]">
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <div>
            <h1 className="font-bold text-base md:text-lg text-[#1c1c19]">Writing Coach Mission</h1>
            <p className="text-xs text-[#888780]">Weekly Focus: Complex Sentence Mastery</p>
          </div>
        </div>

        {/* State Toggle for demo */}
        <div className="flex items-center gap-2 bg-[#f6f3ee] p-1 rounded-full border border-[#c8c4d5]/40 text-xs font-semibold">
          <button
            onClick={() => setViewState('mission')}
            className={`px-3 py-1 rounded-full transition-all ${
              viewState === 'mission' ? 'bg-[#3b309e] text-white shadow' : 'text-[#474553] hover:text-[#1c1c19]'
            }`}
          >
            Mission Input
          </button>
          <button
            onClick={() => setViewState('graded')}
            className={`px-3 py-1 rounded-full transition-all ${
              viewState === 'graded' ? 'bg-[#3b309e] text-white shadow' : 'text-[#474553] hover:text-[#1c1c19]'
            }`}
          >
            Graded Result
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-[1000px] mx-auto p-6 md:p-10 space-y-8">
        {viewState === 'mission' ? (
          <div className="space-y-6">
            {/* Banner */}
            <div className="bg-[#534ab7] text-white rounded-3xl p-8 shadow-lg relative overflow-hidden">
              <div className="relative z-10 space-y-2">
                <span className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold text-white">WEEK 3 • MISSION 2</span>
                <h2 className="font-extrabold text-2xl md:text-3xl">Subordinating Conjunctions</h2>
                <p className="text-xs text-[#e3dfff] max-w-xl leading-relaxed">
                  Combine two simple contrasting sentences into a single, cohesive academic sentence using 'Although' or 'Whereas'.
                </p>
              </div>
            </div>

            {/* Stimulus Card */}
            <div className="bg-white rounded-2xl p-6 border border-[#c8c4d5]/30 shadow-sm space-y-4">
              <h3 className="font-bold text-xs uppercase tracking-wider text-[#888780]">Sentence Stimulus</h3>
              <div className="space-y-2 text-sm text-[#2C2C2A] font-medium bg-[#f6f3ee] p-4 rounded-xl border border-[#ebe8e2]">
                <p>1. Online learning offers unprecedented flexibility for adult professionals.</p>
                <p>2. Online learning frequently lacks social accountability and peer interaction.</p>
              </div>
            </div>

            {/* Input Box */}
            <div className="bg-white rounded-2xl p-6 border border-[#3b309e]/30 shadow-md space-y-4">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#3b309e]">Your Combined Sentence</label>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                rows={4}
                className="w-full p-4 rounded-xl bg-[#f6f3ee]/50 text-sm text-[#1c1c19] border border-[#c8c4d5]/30 focus:outline-none focus:bg-white focus:border-[#3b309e] focus:ring-2 focus:ring-[#3b309e]/10 transition-all resize-none"
              />

              <div className="flex justify-end">
                <button
                  onClick={() => setViewState('graded')}
                  className="px-8 py-3 rounded-full bg-[#3b309e] text-white font-semibold text-sm shadow-md hover:bg-[#534ab7] transition-all active:scale-95 flex items-center gap-2"
                >
                  Submit Sentence
                  <span className="material-symbols-outlined text-[18px]">send</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* State B: Graded Result */
          <div className="space-y-6 animate-in fade-in">
            <div className="bg-white rounded-3xl p-8 border border-[#c8c4d5]/30 shadow-md space-y-6">
              <div className="flex items-center justify-between pb-6 border-b border-[#f1ede8]">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#E1F5EE] text-[#0F6E56] flex items-center justify-center font-bold text-xl">
                    7.5
                  </div>
                  <div>
                    <h2 className="font-bold text-lg text-[#1c1c19]">Grammatical Mastery Achieved</h2>
                    <p className="text-xs text-[#888780]">Evaluated by ST.ELLA Writing Coach</p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full bg-[#E1F5EE] text-[#0F6E56] text-xs font-bold">
                  Passed Mission
                </span>
              </div>

              {/* Submitted Sentence Display */}
              <div className="bg-[#f6f3ee] p-5 rounded-2xl border border-[#c8c4d5]/20 space-y-2">
                <span className="text-[10px] font-bold text-[#888780] uppercase">Submitted Sentence</span>
                <p className="text-sm font-medium text-[#1c1c19] leading-relaxed">
                  "{inputText}"
                </p>
              </div>

              {/* Feedback Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-[#E1F5EE]/40 border border-[#0F6E56]/20 space-y-1">
                  <span className="text-xs font-bold text-[#0F6E56] flex items-center gap-1">
                    <span className="material-symbols-outlined text-sm">thumb_up</span> What Went Well
                  </span>
                  <p className="text-xs text-[#1c1c19]">
                    Excellent use of the complex subordinator 'Although' to establish contrast seamlessly without run-on errors.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-[#fff7e6] border border-[#D97706]/20 space-y-1">
                  <span className="text-xs font-bold text-[#D97706] flex items-center gap-1">
                    <span className="material-symbols-outlined text-sm">lightbulb</span> Upgrade Opportunity
                  </span>
                  <p className="text-xs text-[#1c1c19]">
                    Replace 'frequently lacks' with 'is inherently deprived of' for higher lexical formality.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-[#f1ede8]">
                <button
                  onClick={() => setViewState('mission')}
                  className="px-6 py-2.5 rounded-full border border-[#c8c4d5] text-[#474553] text-xs font-semibold hover:bg-[#f6f3ee]"
                >
                  Try Another Sentence
                </button>
                <button
                  onClick={() => onNavigate('revision')}
                  className="px-6 py-2.5 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow hover:bg-[#534ab7]"
                >
                  Go to Revision Workspace
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
