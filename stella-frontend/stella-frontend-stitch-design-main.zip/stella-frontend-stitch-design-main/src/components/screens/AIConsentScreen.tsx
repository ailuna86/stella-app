import React, { useState } from 'react';
import { ScreenId } from '../../types';

interface Props {
  onNavigate: (screen: ScreenId) => void;
}

export const AIConsentScreen: React.FC<Props> = ({ onNavigate }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [agreed, setAgreed] = useState(false);

  const handleAgree = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setAgreed(true);
      setTimeout(() => {
        onNavigate('dashboard');
      }, 1000);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#fcf9f3] text-[#1c1c19] flex flex-col items-center justify-center relative overflow-hidden p-6">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-[#c5c0ff]/20 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-[#e4dfff]/30 blur-[150px]" />
      </div>

      <main className="relative z-10 w-full max-w-[560px] my-6">
        {/* Onboarding Progress */}
        <div className="mb-6 flex justify-center">
          <div className="w-32 h-1 bg-[#e5e2dd] rounded-full overflow-hidden">
            <div className="w-3/4 h-full bg-[#3b309e] transition-all duration-700 ease-out" />
          </div>
        </div>

        {/* Content Card */}
        <div className="glass-card rounded-[32px] p-8 md:p-12 shadow-[0px_4px_20px_rgba(83,74,183,0.08)] flex flex-col items-center text-center">
          {/* Illustration / Icon Area */}
          <div className="mb-8 relative">
            <div className="w-24 h-24 rounded-full bg-[#e3dfff] flex items-center justify-center animate-pulse">
              <span className="material-symbols-outlined text-[#3b309e] text-[48px] fill-1">
                neurology
              </span>
            </div>
            <div className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center border border-[#E1F5EE]">
              <span className="material-symbols-outlined text-[#0F6E56] text-[20px] fill-1">
                verified_user
              </span>
            </div>
          </div>

          {/* Typography */}
          <header className="mb-8">
            <h1 className="font-bold text-2xl md:text-3xl text-[#1c1c19] mb-4">
              Fair & Accurate Feedback
            </h1>
            <p className="text-base text-[#474553] leading-relaxed">
              To provide you with instant, detailed scoring across all IELTS criteria, your essay is processed by our proprietary AI engine.
            </p>
          </header>

          {/* Info Bento Grid */}
          <div className="grid grid-cols-1 gap-3 w-full mb-8 text-left">
            <div className="bg-[#f6f3ee] p-4 md:p-5 rounded-2xl flex gap-4 items-start border border-[#c8c4d5]/30">
              <span className="material-symbols-outlined text-[#3b309e] mt-1">psychology</span>
              <div>
                <h3 className="font-semibold text-sm text-[#1c1c19]">Smart AI Scoring</h3>
                <p className="text-xs text-[#888780] leading-normal">Our AI analyzes Lexical Resource, Cohesion, and Task Response just like a real examiner.</p>
              </div>
            </div>

            <div className="bg-[#f6f3ee] p-4 md:p-5 rounded-2xl flex gap-4 items-start border border-[#c8c4d5]/30">
              <span className="material-symbols-outlined text-[#3b309e] mt-1">visibility</span>
              <div>
                <h3 className="font-semibold text-sm text-[#1c1c19]">Tutor Supervision</h3>
                <p className="text-xs text-[#888780] leading-normal">Your assigned IELTS Expert can view your processed essays to refine your study plan.</p>
              </div>
            </div>

            <div className="bg-[#f6f3ee] p-4 md:p-5 rounded-2xl flex gap-4 items-start border border-[#c8c4d5]/30">
              <span className="material-symbols-outlined text-[#3b309e] mt-1">lock</span>
              <div>
                <h3 className="font-semibold text-sm text-[#1c1c19]">Privacy First</h3>
                <p className="text-xs text-[#888780] leading-normal">Your data is encrypted and never used for external model training without your permission.</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="w-full">
            <button
              onClick={handleAgree}
              disabled={isProcessing || agreed}
              className={`w-full font-semibold text-sm py-4 rounded-full shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 ${
                agreed
                  ? 'bg-[#0F6E56] text-white'
                  : 'bg-[#3b309e] text-white hover:bg-[#534ab7]'
              }`}
            >
              {isProcessing ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Processing...
                </>
              ) : agreed ? (
                <>
                  <span className="material-symbols-outlined">check_circle</span>
                  Agreement Saved
                </>
              ) : (
                <>
                  I understand and agree
                  <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
                </>
              )}
            </button>

            <p className="mt-5 text-xs text-[#888780]">
              By continuing, you agree to our <a href="#" className="text-[#3b309e] hover:underline font-medium">Privacy Policy</a> and <a href="#" className="text-[#3b309e] hover:underline font-medium">Data Processing Terms</a>.
            </p>
          </div>
        </div>

        {/* GDPR Badges */}
        <div className="mt-6 flex justify-center items-center gap-6 text-[#888780]">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">verified</span>
            <span className="text-xs font-medium">GDPR Compliant</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">shield</span>
            <span className="text-xs font-medium">Secure Processing</span>
          </div>
        </div>
      </main>
    </div>
  );
};
