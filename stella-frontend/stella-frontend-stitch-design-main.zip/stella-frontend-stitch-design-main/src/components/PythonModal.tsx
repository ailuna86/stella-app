import React, { useState } from 'react';

interface PythonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonModal: React.FC<PythonModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const pythonCode = `"""
IELTS Expert & AI Writing Coach - Python Backend Service
-------------------------------------------------------
FastAPI REST API supporting Essay Scoring, Vocabulary Analysis,
Revision Workspaces, and Student Roster Management.

Install dependencies:
    pip install fastapi uvicorn pydantic python-dotenv google-genai

Run server:
    uvicorn app:app --reload --port 8000
"""

import os
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(
    title="IELTS Expert AI Backend",
    description="Python Backend for IELTS Writing & Feedback Platform",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class EssaySubmission(BaseModel):
    prompt: str
    essay_text: str
    task_type: str = Field(default="Writing Task 2")
    target_band: float = 7.5

@app.post("/api/evaluate-essay")
def evaluate_essay(submission: EssaySubmission):
    words = len(submission.essay_text.split())
    if words < 50:
        raise HTTPException(status_code=400, detail="Essay too short")
    return {
        "overall_band": 7.5,
        "criteria": {
            "task_response": 8.0,
            "coherence_cohesion": 7.5,
            "lexical_resource": 6.5,
            "grammatical_accuracy": 8.0
        },
        "word_count": words,
        "cefr": "C1 Advanced"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
`;

  const handleDownload = () => {
    const blob = new Blob([pythonCode], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'app.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-[#c8c4d5] flex flex-col max-h-[85vh]">
        <div className="flex justify-between items-center pb-4 border-b border-[#f1ede8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#e3dfff] flex items-center justify-center text-[#3b309e]">
              <span className="material-symbols-outlined">code</span>
            </div>
            <div>
              <h3 className="font-bold text-lg text-[#1c1c19]">Python Backend File (app.py)</h3>
              <p className="text-xs text-[#888780]">Ready-to-use FastAPI backend boilerplate for your custom logic.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#888780]">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="my-4 flex-1 overflow-auto rounded-xl bg-[#1c1c19] text-[#e3dfff] p-4 font-mono text-xs custom-scrollbar">
          <pre>{pythonCode}</pre>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-[#f1ede8]">
          <span className="text-xs text-[#888780]">File: <code className="bg-[#f6f3ee] px-2 py-0.5 rounded text-[#3b309e]">app.py</code></span>
          <div className="flex gap-3">
            <button
              onClick={handleCopy}
              className="px-4 py-2 rounded-full border border-[#3b309e] text-[#3b309e] text-xs font-semibold hover:bg-[#e3dfff]/30 transition-colors flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">content_copy</span>
              {copied ? 'Copied!' : 'Copy Python Code'}
            </button>
            <button
              onClick={handleDownload}
              className="px-5 py-2 rounded-full bg-[#3b309e] text-white text-xs font-semibold shadow-md hover:bg-[#534ab7] transition-all active:scale-95 flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              Download .py File
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
