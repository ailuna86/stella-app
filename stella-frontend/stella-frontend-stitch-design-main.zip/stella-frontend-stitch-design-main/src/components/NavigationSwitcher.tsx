import React, { useState } from 'react';
import { ScreenId } from '../types';

interface NavigationSwitcherProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  onOpenPythonModal: () => void;
}

export const NavigationSwitcher: React.FC<NavigationSwitcherProps> = ({
  currentScreen,
  onNavigate,
  onOpenPythonModal,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const screens: { id: ScreenId; label: string; icon: string; badge?: string }[] = [
    { id: 'dashboard', label: 'Student Dashboard', icon: 'dashboard' },
    { id: 'gold_dashboard', label: 'Gold Workspace', icon: 'stars', badge: 'Gold' },
    { id: 'practice', label: 'Practice & Essay Writer', icon: 'edit_square' },
    { id: 'writing_coach', label: 'Sentence Coach', icon: 'edit_note' },
    { id: 'revision', label: 'Revision Workspace', icon: 'history_edu' },
    { id: 'essay_comparison', label: 'Essay Comparison', icon: 'compare' },
    { id: 'vocab_coach', label: 'Vocabulary Coach', icon: 'translate' },
    { id: 'feedback_report', label: 'Feedback Report', icon: 'analytics' },
    { id: 'study_plan', label: 'IELTS Study Plan', icon: 'event_repeat' },
    { id: 'trainer_console', label: 'Trainer Console', icon: 'supervisor_account', badge: 'Examiner' },
    { id: 'pricing', label: 'Pricing Plans', icon: 'payments' },
    { id: 'signin', label: 'Sign In / OTP', icon: 'lock' },
    { id: 'onboarding', label: 'Test Selection', icon: 'school' },
    { id: 'ai_consent', label: 'AI Consent Modal', icon: 'shield' },
    { id: 'coming_soon', label: 'Coming Soon Screen', icon: 'construction' }
  ];

  return (
    <>
      {/* Floating Action Pill Bar */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-[#1c1c19]/90 text-white p-2 px-4 rounded-full shadow-2xl backdrop-blur-md border border-white/20">
        {/* Python Backend Download CTA */}
        <button
          onClick={onOpenPythonModal}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#3b309e] text-white text-xs font-bold shadow hover:bg-[#534ab7] transition-all active:scale-95 border border-white/20"
        >
          <span className="material-symbols-outlined text-[16px] text-[#e3dfff]">code</span>
          <span>Python Backend (.py)</span>
        </button>

        <div className="h-4 w-[1px] bg-white/20 my-auto" />

        {/* Screen Switcher Drawer Trigger */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold transition-colors"
        >
          <span className="material-symbols-outlined text-[16px]">view_carousel</span>
          <span className="hidden sm:inline">Screen:</span>
          <span className="text-[#d1ccff] font-bold">
            {screens.find((s) => s.id === currentScreen)?.label || currentScreen}
          </span>
          <span className="material-symbols-outlined text-[16px]">
            {isOpen ? 'expand_more' : 'expand_less'}
          </span>
        </button>
      </div>

      {/* Screen Selector Drawer Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-[#c8c4d5]/40 max-h-[80vh] flex flex-col animate-in slide-in-from-bottom-4">
            <div className="flex items-center justify-between pb-4 border-b border-[#f1ede8]">
              <div>
                <h3 className="font-bold text-lg text-[#1c1c19]">Screen Showcase Navigator</h3>
                <p className="text-xs text-[#888780]">Select any screen to preview and test design interactions.</p>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-2 rounded-full hover:bg-[#f6f3ee] text-[#888780]">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-4 overflow-auto custom-scrollbar p-1">
              {screens.map((screen) => (
                <button
                  key={screen.id}
                  onClick={() => {
                    onNavigate(screen.id);
                    setIsOpen(false);
                  }}
                  className={`flex items-center justify-between p-3 rounded-2xl text-left text-xs font-semibold transition-all border ${
                    currentScreen === screen.id
                      ? 'bg-[#3b309e] text-white border-[#3b309e] shadow'
                      : 'bg-[#f6f3ee] text-[#1c1c19] border-transparent hover:border-[#c8c4d5]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="material-symbols-outlined text-[18px]">{screen.icon}</span>
                    <span>{screen.label}</span>
                  </div>
                  {screen.badge && (
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      currentScreen === screen.id ? 'bg-white/20 text-white' : 'bg-[#D97706]/15 text-[#D97706]'
                    }`}>
                      {screen.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-[#f1ede8] flex justify-between items-center text-xs text-[#888780]">
              <span>Need the Python backend code?</span>
              <button
                onClick={() => {
                  setIsOpen(false);
                  onOpenPythonModal();
                }}
                className="text-[#3b309e] font-bold hover:underline"
              >
                Download app.py
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
